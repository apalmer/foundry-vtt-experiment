/**
 * Flee, Mortals! Custom Import Module
 * 
 * This module provides 339 creatures from MCDM's Flee, Mortals! monster book.
 * Actors are stored as JSON files and imported into world compendiums on demand.
 */

const MODULE_ID = "flee-mortals-custom";
const BATCH_SIZE = 25;
const DELAY_MS = 50;

// Categories and their labels
const CATEGORIES = {
  creatures: { label: "Flee, Mortals! Creatures", count: 285 },
  companions: { label: "Flee, Mortals! Companions", count: 31 },
  retainers: { label: "Flee, Mortals! Retainers", count: 23 }
};

/**
 * Register module settings
 */
Hooks.once("init", () => {
  game.settings.register(MODULE_ID, "imported", {
    name: "Actors Imported",
    hint: "Whether the actors have been imported to compendiums",
    scope: "world",
    config: false,
    type: Boolean,
    default: false
  });
  
  game.settings.register(MODULE_ID, "importVersion", {
    name: "Import Version",
    hint: "Version of the last import",
    scope: "world",
    config: false,
    type: String,
    default: ""
  });
});

/**
 * Add button to Compendium sidebar when ready
 */
Hooks.once("ready", async () => {
  // Only for GMs
  if (!game.user.isGM) return;
  
  // Check if already imported
  const imported = game.settings.get(MODULE_ID, "imported");
  
  if (!imported) {
    // Show dialog prompting to import
    showImportDialog();
  }
});

/**
 * Register the import button in the compendium sidebar
 */
Hooks.on("renderCompendiumDirectory", (app, html, data) => {
  if (!game.user.isGM) return;
  
  // Add import button to the header
  const header = html.find(".directory-header");
  const importButton = $(`
    <button class="fm-import-btn" title="Import Flee, Mortals! Creatures">
      <i class="fas fa-dragon"></i> Import Flee, Mortals!
    </button>
  `);
  
  importButton.on("click", (event) => {
    event.preventDefault();
    showImportDialog();
  });
  
  header.append(importButton);
});

/**
 * Show the import dialog
 */
function showImportDialog() {
  const imported = game.settings.get(MODULE_ID, "imported");
  
  const content = imported 
    ? `<p>Flee, Mortals! creatures have already been imported.</p>
       <p>Do you want to re-import? This will create duplicates if the existing compendiums are not cleared first.</p>
       <p><strong>Categories:</strong></p>
       <ul>
         <li>Creatures: ${CATEGORIES.creatures.count}</li>
         <li>Companions: ${CATEGORIES.companions.count}</li>
         <li>Retainers: ${CATEGORIES.retainers.count}</li>
       </ul>`
    : `<p>This will import 339 creatures from Flee, Mortals! into world compendiums.</p>
       <p><strong>Categories:</strong></p>
       <ul>
         <li>Creatures: ${CATEGORIES.creatures.count}</li>
         <li>Companions: ${CATEGORIES.companions.count}</li>
         <li>Retainers: ${CATEGORIES.retainers.count}</li>
       </ul>
       <p>This may take a minute. A progress notification will appear.</p>`;
  
  new Dialog({
    title: "Flee, Mortals! Import",
    content: content,
    buttons: {
      import: {
        icon: '<i class="fas fa-file-import"></i>',
        label: "Import",
        callback: () => runImport()
      },
      cancel: {
        icon: '<i class="fas fa-times"></i>',
        label: "Cancel"
      }
    },
    default: "import"
  }).render(true);
}

/**
 * Main import function
 */
async function runImport() {
  const startTime = Date.now();
  
  ui.notifications.info("Flee, Mortals! Import starting...", { permanent: false });
  
  const results = {
    creatures: { success: 0, errors: 0 },
    companions: { success: 0, errors: 0 },
    retainers: { success: 0, errors: 0 }
  };
  
  // Import each category
  for (const [category, info] of Object.entries(CATEGORIES)) {
    try {
      const result = await importCategory(category, info.label);
      results[category] = result;
    } catch (error) {
      console.error(`${MODULE_ID} | Error importing ${category}:`, error);
      results[category] = { success: 0, errors: 1, error: error.message };
    }
  }
  
  // Calculate totals
  const totalSuccess = Object.values(results).reduce((sum, r) => sum + r.success, 0);
  const totalErrors = Object.values(results).reduce((sum, r) => sum + r.errors, 0);
  const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
  
  // Mark as imported
  await game.settings.set(MODULE_ID, "imported", true);
  await game.settings.set(MODULE_ID, "importVersion", game.modules.get(MODULE_ID).version);
  
  // Show completion notification
  if (totalErrors === 0) {
    ui.notifications.info(`Flee, Mortals! Import complete: ${totalSuccess} actors in ${elapsed}s`);
  } else {
    ui.notifications.warn(`Flee, Mortals! Import complete: ${totalSuccess} actors, ${totalErrors} errors (${elapsed}s)`);
  }
  
  console.log(`${MODULE_ID} | Import complete:`, results);
  
  // Refresh compendium sidebar
  ui.compendium.render();
  
  return results;
}

/**
 * Import a single category of actors
 */
async function importCategory(category, label) {
  console.log(`${MODULE_ID} | Importing ${category}...`);
  
  // Load the manifest
  const manifestPath = `modules/${MODULE_ID}/actors/${category}/manifest.json`;
  const manifestResponse = await fetch(manifestPath);
  
  if (!manifestResponse.ok) {
    throw new Error(`Failed to load manifest: ${manifestPath}`);
  }
  
  const files = await manifestResponse.json();
  console.log(`${MODULE_ID} | Found ${files.length} files in ${category}`);
  
  // Get or create the compendium
  const pack = await getOrCreatePack(category, label);
  
  let success = 0;
  let errors = 0;
  
  // Process in batches
  for (let i = 0; i < files.length; i += BATCH_SIZE) {
    const batch = files.slice(i, i + BATCH_SIZE);
    const batchNum = Math.floor(i / BATCH_SIZE) + 1;
    const totalBatches = Math.ceil(files.length / BATCH_SIZE);
    
    // Update progress
    const progress = Math.round((i / files.length) * 100);
    console.log(`${MODULE_ID} | ${category}: Batch ${batchNum}/${totalBatches} (${progress}%)`);
    
    // Load and create actors in parallel within batch
    const promises = batch.map(async (file) => {
      try {
        const path = `modules/${MODULE_ID}/actors/${category}/${file}`;
        const response = await fetch(path);
        
        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`);
        }
        
        const actorData = await response.json();
        
        // Remove _id to let Foundry generate a new one
        delete actorData._id;
        
        // Create in compendium
        await Actor.create(actorData, { pack: pack.collection });
        
        return { success: true };
      } catch (error) {
        console.error(`${MODULE_ID} | Failed to import ${file}:`, error);
        return { success: false, file, error: error.message };
      }
    });
    
    const results = await Promise.all(promises);
    success += results.filter(r => r.success).length;
    errors += results.filter(r => !r.success).length;
    
    // Small delay between batches
    if (i + BATCH_SIZE < files.length) {
      await new Promise(r => setTimeout(r, DELAY_MS));
    }
  }
  
  console.log(`${MODULE_ID} | ${category} complete: ${success} success, ${errors} errors`);
  
  return { success, errors };
}

/**
 * Get an existing compendium or create a new world compendium
 */
async function getOrCreatePack(name, label) {
  const packId = `world.fm-${name}`;
  
  // Check if pack already exists
  let pack = game.packs.get(packId);
  
  if (!pack) {
    // Create new world compendium
    console.log(`${MODULE_ID} | Creating compendium: ${label}`);
    
    const metadata = {
      name: `fm-${name}`,
      label: label,
      type: "Actor",
      system: "dnd5e",
      package: "world"
    };
    
    pack = await CompendiumCollection.createCompendium(metadata);
  }
  
  // Unlock if locked
  if (pack.locked) {
    await pack.configure({ locked: false });
  }
  
  return pack;
}

/**
 * Utility function to clear a compendium (for re-import)
 */
async function clearCompendium(category) {
  const packId = `world.fm-${category}`;
  const pack = game.packs.get(packId);
  
  if (!pack) {
    console.warn(`${MODULE_ID} | Compendium not found: ${packId}`);
    return;
  }
  
  if (pack.locked) {
    await pack.configure({ locked: false });
  }
  
  const documents = await pack.getDocuments();
  console.log(`${MODULE_ID} | Deleting ${documents.length} actors from ${category}...`);
  
  for (const doc of documents) {
    await doc.delete();
  }
  
  console.log(`${MODULE_ID} | Cleared ${category}`);
}

// Expose functions for console access
window.fleeMortals = {
  import: runImport,
  clearCompendium: clearCompendium,
  clearAll: async () => {
    for (const category of Object.keys(CATEGORIES)) {
      await clearCompendium(category);
    }
    await game.settings.set(MODULE_ID, "imported", false);
    console.log(`${MODULE_ID} | All compendiums cleared`);
  }
};

console.log(`${MODULE_ID} | Module loaded. Use fleeMortals.import() to import actors.`);

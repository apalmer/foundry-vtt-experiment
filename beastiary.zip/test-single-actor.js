/**
 * Flee, Mortals! Quick Test Script
 * 
 * Run this in the Foundry VTT browser console (F12) to test importing a single actor.
 * Prerequisites:
 * 1. The flee-mortals-custom module folder must be in your Foundry Data/modules/ directory
 * 2. Enable the module in Foundry's Module Management
 * 3. You must be logged in as a GM
 * 
 * Usage:
 * 1. Copy this entire script and paste it into the browser console
 * 2. It will automatically test loading the Ankheg actor JSON
 */

(async function() {
    console.log("=".repeat(60));
    console.log("Flee, Mortals! Quick Test");
    console.log("=".repeat(60));
    
    // Check module
    const MODULE_ID = "flee-mortals-custom";
    const module = game.modules.get(MODULE_ID);
    
    if (!module) {
        console.error("Module not found! Make sure flee-mortals-custom folder is in Data/modules/");
        return;
    }
    
    if (!module.active) {
        console.error("Module not active! Enable it in Settings > Manage Modules");
        return;
    }
    
    console.log("Module found and active.");
    
    // Test loading a creature JSON
    const testFile = "modules/flee-mortals-custom/actors/creatures/ankheg.json";
    console.log(`Testing: ${testFile}`);
    
    try {
        const response = await fetch(testFile);
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const actorData = await response.json();
        console.log("JSON loaded successfully!");
        console.log("Actor name:", actorData.name);
        console.log("Type:", actorData.type);
        console.log("HP:", actorData.system?.attributes?.hp?.max);
        console.log("AC:", actorData.system?.attributes?.ac?.flat);
        console.log("CR:", actorData.system?.details?.cr);
        console.log("Items:", actorData.items?.length || 0);
        
        // Test token path
        const tokenPath = actorData.img;
        console.log("Token path:", tokenPath);
        
        const tokenResponse = await fetch(tokenPath);
        if (tokenResponse.ok) {
            console.log("Token image: Found");
        } else {
            console.warn("Token image: NOT FOUND - " + tokenPath);
        }
        
        // Try creating in a test compendium
        console.log("\nAttempting to create actor in world compendium...");
        
        // Create or get test compendium
        let pack = game.packs.get("world.fm-test");
        if (!pack) {
            pack = await CompendiumCollection.createCompendium({
                name: "fm-test",
                label: "Flee, Mortals! Test",
                type: "Actor",
                system: "dnd5e"
            });
            console.log("Created test compendium");
        }
        
        if (pack.locked) {
            await pack.configure({ locked: false });
        }
        
        // Remove _id to let Foundry generate new one
        delete actorData._id;
        
        // Create the actor
        const actor = await pack.createDocument(actorData);
        
        console.log("SUCCESS! Actor created:", actor.name);
        console.log("Actor ID:", actor.id);
        console.log("Items on actor:", actor.items.size);
        
        // Check items
        for (const item of actor.items) {
            console.log(`  - ${item.name} (${item.type})`);
        }
        
        console.log("\n=".repeat(60));
        console.log("TEST PASSED!");
        console.log("Check the 'Flee, Mortals! Test' compendium in the Compendium tab.");
        console.log("=".repeat(60));
        
        ui.notifications.info("Test passed! Check the Flee, Mortals! Test compendium.");
        
    } catch (error) {
        console.error("TEST FAILED:", error);
        ui.notifications.error("Test failed: " + error.message);
    }
})();
